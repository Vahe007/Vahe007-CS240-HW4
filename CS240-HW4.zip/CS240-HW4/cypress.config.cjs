const { defineConfig } = require("cypress");

module.exports = defineConfig({
    e2e: {
        baseUrl: 'https://www.flipkart.com/',
        supportFile: false,
        failOnError: false,
    },
    env: {
        baseUrl: 'https://www.flipkart.com/'
    }
});