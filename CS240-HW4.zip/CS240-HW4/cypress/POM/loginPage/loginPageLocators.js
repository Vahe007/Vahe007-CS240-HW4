export const loginPageLocators = {
    loginTitle: '.KIOyzU',
    loginInput: '[class="r4vIwl mYpCuj BV+Dqf"]',
    requestOptButton: '[class="QqFHMw twnTnD _7Pd1Fp"]',
    invalidEmail: '.llBOFA',
}