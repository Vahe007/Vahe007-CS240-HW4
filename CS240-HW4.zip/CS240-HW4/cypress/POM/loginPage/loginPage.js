import { loginPageLocators } from "./loginPageLocators";

class LoginPage {
    elements = {
        loginTitle: () => cy.get(loginPageLocators.loginTitle),
        loginInput: () => cy.get(loginPageLocators.loginInput),
        requestOptButton: () => cy.get(loginPageLocators.requestOptButton),
        invalidEmail: () => cy.get(loginPageLocators.invalidEmail),
    }

    enterEmail(invalidInput) {
        this.elements.loginInput().clear().type(invalidInput);
    }

    clickRequestOptButton() {
        this.elements.requestOptButton().click();
    }
}

export const loginPage = new LoginPage();