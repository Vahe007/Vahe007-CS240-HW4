export const searchPageLocators = {
    searchTitle: '.BUOuZu',
    firstProduct: '.CGtC98:first',
    addToCompare: '.Lni97G:first',
    addDiscount: '.XqNaEv:first',
    compareSideButton: '.vYpSTw',
}