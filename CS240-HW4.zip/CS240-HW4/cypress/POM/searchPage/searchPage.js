import {searchPageLocators} from "./searchPageLocators";

class SearchPage {
    elements = {
        searchTitle: () =>  cy.get(searchPageLocators.searchTitle),
        addToCompare: () =>  cy.get(searchPageLocators.addToCompare),
        firstProduct: () =>  cy.get(searchPageLocators.firstProduct),
        discount: () =>  cy.get(searchPageLocators.addDiscount),
        compareSideButton: () => cy.get(searchPageLocators.compareSideButton),

    }

    addToCompare = () => {
        this.elements.addToCompare();
    }

    filterDiscount = () => {
        this.elements.discount();
    }



}

export const searchPage = new SearchPage();