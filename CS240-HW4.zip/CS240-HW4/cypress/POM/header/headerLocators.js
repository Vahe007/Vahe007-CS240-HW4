export const headerLocators = {
    headerLogo: '._3EOQ5Q',
    searchInput: '.Pke_EE',
    loginButton: '._1jKL3b',
    shoppingCard: ':nth-child(3) > ._38VF5e > ._1krdK5',
    loginButtonDropdown: '._1TOQfO > span',
    loginDownArrow: '.XdYXbi',
    loginDropDownForm: '._3YjYK7.ecs1XG',
    signUpButton: '._1Mikcj',
}