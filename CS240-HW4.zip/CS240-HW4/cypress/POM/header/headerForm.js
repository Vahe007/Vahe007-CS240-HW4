import {headerLocators} from "./headerLocators";

class HeaderForm {
    elements = {
        headerLogo: () => cy.get(headerLocators.headerLogo),
        searchInput: () => cy.get(headerLocators.searchInput),
        loginButton: () => cy.get(headerLocators.loginButton),
        shappingCard: () => cy.get(headerLocators.shoppingCard),
        loginButtonDropdown: () => cy.get(headerLocators.loginButtonDropdown),
        loginDownArrow: () => cy.get(headerLocators.loginDownArrow),
        loginDropDownForm: () => cy.get(headerLocators.loginDropDownForm),
        signUpButton: () => cy.get(headerLocators.signUpButton),
    }

    clickHeaderLogo() {
        this.elements.headerLogo().click();
    }

    typeInSearchField(productName) {
        this.elements.searchInput().clear().type(productName);
    }

    performSearch(productName) {
        this.typeInSearchField(`${productName}{enter}`);
    }

    navigateToLogin() {
        this.elements.loginButton().click();
    }

    navigateToCard() {
        this.elements.shappingCard().click();
    }

    hoverLoginDropDown() {
        this.elements.loginButtonDropdown().trigger('mouseover');
    }

    clickLoginDownArrow() {
        this.elements.loginDownArrow().click();
    }

    navigateToSignUp() {
        this.elements.signUpButton().click();
    }

}

export const headerForm = new HeaderForm();