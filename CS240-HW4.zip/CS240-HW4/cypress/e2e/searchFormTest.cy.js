import {headerForm} from "../POM/header/headerForm";


describe('Search Form', () => {
    beforeEach(() => {
        cy.viewport(1800, 1000);
        cy.visit('https://www.flipkart.com/', {failOnStatusCode: false});
    })

    it('should search page for specific product', () => {
        const mockedProductName = 'Iphone 14'

        headerForm.performSearch(mockedProductName);
        cy.url().should('include', '/searchPage');

    });
});
