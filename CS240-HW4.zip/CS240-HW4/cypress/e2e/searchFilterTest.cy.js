import {headerForm} from '../POM/header/headerForm';
import {searchPage} from "../POM/searchPage/searchPage";

describe('Flipkart - Searching and filtering', () => {
    Cypress.on('uncaught:exception', (err, runnable) => {
        return false;
    });

    beforeEach(() => {
        cy.viewport(1800, 1000);
        cy.visit('/', { failOnStatusCode: false });

        const mockedProductName = 'iphone 15 plus'
        headerForm.performSearch(mockedProductName);
    });

    it('should search for an iphone', () => {
        cy.url().should('include', '/searchPage');
    })

    it('should navigate back to homepage when header logo is clicked', () => {
        headerForm.elements.headerLogo().click();
        headerForm.elements.searchInput().should('exist');
    });

    it('should add the first product to compare', () => {
        searchPage.addToCompare();
        cy.contains('Add to Compare').should('exist');
        searchPage.elements.compareSideButton().should('exist');
    });

    it('should filter products by discount', () => {
        searchPage.filterDiscount();
        cy.contains('30% off').should('exist');
    });

})