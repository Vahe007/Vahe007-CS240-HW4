import {loginPage} from "../POM/loginPage/loginPage";
import {headerForm} from "../POM/header/headerForm";

describe('LoginPage', () => {
    beforeEach(() => {
        cy.viewport(1800, 1000);
    })

    it('should navigate to login page', () => {
        cy.visit('', {failOnStatusCode: false});
        headerForm.elements.loginButton().click();
        loginPage.elements.loginTitle().should('exist');
    });

    it('should display message when wrong email is entered', () => {
        cy.visit('/login', {failOnStatusCode: false});
        loginPage.enterEmail('invalid mail input');
        loginPage.clickRequestOptButton();
        loginPage.elements.invalidEmail().should('exist')
    })

    it('should navigate back to homepage when header logo is clicked', () => {
        cy.visit('/login', {failOnStatusCode: false});
        headerForm.elements.headerLogo().click()
        headerForm.elements.searchInput().should('exist')
    })

});