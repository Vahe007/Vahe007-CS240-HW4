import {headerForm} from '../POM/header/headerForm';

describe('Flipkart - Header Elements verification', () => {
    Cypress.on('uncaught:exception', (err, runnable) => {
        return false;
    });

    beforeEach(() => {
        cy.viewport(1800, 1000);
        cy.visit('', {failOnStatusCode: false});
    })

    it('Verify Header Elements should be visible', () => {
        headerForm.elements.headerLogo().should('exist');
        headerForm.elements.searchInput().should('exist').and('be.empty');
        headerForm.elements.loginButton().should('be.visible');
        headerForm.elements.shappingCard().should('be.visible');
        headerForm.elements.loginButtonDropdown().should('be.visible');
    })

    it('login dropdown should be visible with 7 item when login is hovered', () => {
        headerForm.hoverLoginDropDown();
        headerForm.elements.loginButtonDropdown().should('be.visible');
        cy.get("._3YjYK7.ecs1XG").find("a").should('have.length', 7);
    })

    it('login dropdown should be visible with 7 item when login down arrow is clicked', () => {
        headerForm.elements.loginDownArrow().should('be.visible');
        headerForm.clickLoginDownArrow();

        headerForm.elements.loginDropDownForm().find("a").should('have.length', 7);
    })

    it('should navigate to signup page', () => {
        headerForm.elements.signUpButton().click();
        cy.url().should('include', '/login');

    })


})